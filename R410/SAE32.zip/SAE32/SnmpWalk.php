<?php
print_r(snmpwalk('192.168.1.1','public','1.3') ) ;
?>


